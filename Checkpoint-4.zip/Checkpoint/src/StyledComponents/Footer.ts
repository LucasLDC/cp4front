import styled from "styled-components";

export const FundoFooter = styled.div`
    background-color: lightgray;
`