import { Link } from "react-router-dom";
import styled from "styled-components";

export const MenuLink = styled(Link)`
    color: darkRed;
`