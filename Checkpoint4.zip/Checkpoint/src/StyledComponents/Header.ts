import styled from "styled-components";
 
export const FundoHeader = styled.div`
   
        margin: 0;
   
        background-color: lightgray;
`